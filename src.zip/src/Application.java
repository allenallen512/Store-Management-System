import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Application {
    public DataAccess dataAdapter = new SQLDataAdaptor();

    public AddJobView jobView = new AddJobView();
    public AddEmployeeView employeeView = new AddEmployeeView();
    private JPanel cardPanel;
    private CardLayout cardLayout;
    private static Application instance;   // Singleton pattern

    public static Application getInstance() {
        if (instance == null) {
            instance = new Application();
        }
        return instance;
    }


    //used online resources to see how I could make everythign appear in one window instead of seperate windows.

    public static void main(String[] args) {

        System.out.println("Hello world!");
        Application application = Application.getInstance();
        application.dataAdapter.connect();

//        application.employeeView.setVisible(true);


        JFrame homepageFrame = new JFrame("Homepage");
        homepageFrame.setSize(500, 300);
        homepageFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        homepageFrame.setLayout(new FlowLayout());

        // Button for Job Class
        JButton jobClassButton = new JButton("Click for Job Class");
        jobClassButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                application.jobView.setVisible(true);
            }
        });
        homepageFrame.add(jobClassButton);

        // Button for Employee
        JButton employeeButton = new JButton("Click for Employee Class");
        employeeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                application.employeeView.setVisible(true);
            }
        });
        homepageFrame.add(employeeButton);

        // Make the homepage frame visible
        homepageFrame.setVisible(true);
    }
    }
