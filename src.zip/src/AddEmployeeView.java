import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddEmployeeView extends JFrame {
    private JTextField employeeIDField;
    private JTextField employeeNameField;
    private JTextField employeeJobClass;
    private JButton addEmployee;
    private JButton updateEmployee;
    private JButton readButton;
    private JButton deleteButton;

    private void displayEmployeeDetails(Employee employee){
        JFrame details = new JFrame("Job Details");

        details.setSize(300,200);
        details.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        details.setLayout(new GridLayout(3,1));

        JLabel idLabel = new JLabel("ID: " + employee.id);
        JLabel nameLabel = new JLabel("Employee Name: " + employee.employeeName);
        JLabel classLabel = new JLabel("Employee Job Class: " + employee.jobClass);

        details.add(idLabel);
        details.add(nameLabel);
        details.add(classLabel);

        details.setVisible(true);
    }

    public AddEmployeeView() {
        setTitle("Add Job Class");
        this.setSize(500, 300);

        this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));

        this.getContentPane().add(new JLabel ("Employee View"));

//        JPanel main = new JPanel(new SpringLayout());
        JPanel main = new JPanel(new GridLayout(4,2,5,5));

        main.add(new JLabel("Employee ID: "));
        employeeIDField= new JTextField();
        main.add(employeeIDField);

        main.add(new JLabel("Employee Name: "));
        employeeNameField = new JTextField();
        main.add(employeeNameField);

        main.add(new JLabel("Job Class: "));
        employeeJobClass = new JTextField();
        main.add(employeeJobClass);

        addEmployee = new JButton("Add Employee");
        addEmployee.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int employeeID;
                try {
                    employeeID = Integer.parseInt(employeeIDField.getText());
                }
                catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid Employee ID! Please provide a valid ID!");
                    return;
                }

                String employeeName = employeeNameField.getText().trim();
                if (employeeName.length() == 0) {
                    JOptionPane.showMessageDialog(null, "enter a valid employee name");
                }

                int jobClass;
                try {
                    jobClass = Integer.parseInt(employeeJobClass.getText());
                }
                catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid employee job class");
                    return;
                }

                // Done all validations! Make an object for this product!

                Employee employee = new Employee(employeeID, employeeName, jobClass);

                // Store the model to the database

                boolean res = Application.getInstance().dataAdapter.createEmployee(employee);
                if (!res) {
                    JOptionPane.showMessageDialog(null, "Employee is NOT saved!");
                }
                else {
                    JOptionPane.showMessageDialog(null, "Employee created!");
                }

            }
        });

        updateEmployee = new JButton("Update Employee");
        updateEmployee.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int employeeID;
                try {
                    employeeID = Integer.parseInt(employeeIDField.getText());
                }
                catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid Employee ID! Please provide a valid ID!");
                    return;
                }

                String employeeName = employeeNameField.getText().trim();
                if (employeeName.length() == 0) {
                    JOptionPane.showMessageDialog(null, "enter a valid employee name");
                }

                int jobClass;
                try {
                    jobClass = Integer.parseInt(employeeJobClass.getText());
                }
                catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid employee job class");
                    return;
                }

                // Done all validations! Make an object for this product!

                Employee employee = new Employee(employeeID, employeeName, jobClass);

                // Store the model to the database

                boolean res = Application.getInstance().dataAdapter.updateEmployee(employee);
                if (!res) {
                    JOptionPane.showMessageDialog(null, "Employee is NOT updated!");
                }
                else {
                    JOptionPane.showMessageDialog(null, "Employee updated!");
                }

            }
        });

        readButton = new JButton("Read Employee");
        readButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id;
                try {
                    id = Integer.parseInt(employeeIDField.getText());
                }
                catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid employee ID! Please provide a valid ID!");
                    return;
                }

                Employee result = Application.getInstance().dataAdapter.readEmployee(id);
                if (result == null) {
                    JOptionPane.showMessageDialog(null, "Employee with id: " + id + " was not found");
                }
                else {
                    displayEmployeeDetails(result);
                }

            }
        });

        deleteButton = new JButton("Delete Employee");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id;
                try {
                    id = Integer.parseInt(employeeIDField.getText());
                }
                catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid employee ID! Please provide a valid ID!");
                    return;
                }

                Employee result = Application.getInstance().dataAdapter.deleteEmployee(id);
                if (result == null) {
                    JOptionPane.showMessageDialog(null, "Employee with id: " + id + " was not found");
                }
                else {
                    JOptionPane.showMessageDialog(null, "Employee Deleted");
                }

            }
        });

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
//        SpringUtilities.makeCompactGrid(main,
//                3, 2, //rows, cols
//                6, 6,        //initX, initY
//                6, 6);       //xPad, yPad
        buttonPanel.add(addEmployee);
        buttonPanel.add(updateEmployee);
        buttonPanel.add(readButton);
        buttonPanel.add(deleteButton);

        add(main, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);


    }

}