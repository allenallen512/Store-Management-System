public interface DataAccess {
    public int connect();

    public int disconnect();


//    CRUD for job class

    public boolean  createJobClass(JobModel job);

    public JobModel readJobClass(int id);

    public boolean  updateJobClass(JobModel job);

    public JobModel deleteJobClass(int id);

//    CRUD for employee models

    public boolean createEmployee (Employee employee);

    public Employee readEmployee(int id);

    public boolean updateEmployee(Employee employee);

    public Employee deleteEmployee(int id);


}
