public class Employee {

    public int id;

    public String employeeName;

    public int jobClass;

    public Employee() {
        this.id = 999;
        this.employeeName = "John Doe ";
        this.jobClass = 1;
    }

    public  Employee(int id, String name, int jobClass) {
        this.id = id;
        this.employeeName = name;
        this.jobClass = jobClass;
    }
}
