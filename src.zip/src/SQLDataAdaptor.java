import com.mysql.cj.x.protobuf.MysqlxPrepare;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;

public class SQLDataAdaptor implements DataAccess {

    private Connection connection = null;
    @Override
    public int connect() {
        String url = "jdbc:mysql://localhost:3306/jdbc_test";
        String username = "root";
         String password = "lflrong1";
        try {
//            Class.forName("com.mysql.cj.jdbc.Driver");

            connection = DriverManager.getConnection(url, username, password);

        }
        catch (Exception e) {
            System.out.println("SQLite is not installed. System exits with error!");
            e.printStackTrace();
            System.exit(1);
        }

        return 0;
    }

    @Override
    public int disconnect() {
        try {
        connection.close();
        } catch (SQLException ex) {
            System.out.println("SQLite database cannot be closed. System exits with error!" + ex.getMessage());
        }
        return 0;
    }

    @Override
    public boolean createJobClass(JobModel job) {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO jobs (job_id, job_title, wage) VALUES (?, ?, ?)");
            statement.setInt(1, job.id);
            statement.setString(2, job.title);
            statement.setDouble(3, job.wage);
            int rows = statement.executeUpdate();
            return rows>0;
        } catch (SQLException ex) {
            System.out.println("SQLite database is not ready. System exits with error!" + ex.getMessage());
            return false;
        }
   }

    @Override
    public JobModel readJobClass(int id) {
        try{
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM jobs WHERE job_id = ?");
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                int jobId = resultSet.getInt("job_id");
                String title = resultSet.getString("job_title");
                double wage = resultSet.getDouble("wage");

                // Create and return a JobModel object with the retrieved data
                return new JobModel(jobId, title, wage);
            } else {
                // Job with the given ID not found
                System.out.println("Job with ID " + id + " not found.");
                return null;
            }

        }
        catch (Exception e) {
            System.out.println("There was an error in the read job class function: " + e.getMessage());
            return null;
        }
    }

    @Override
    public boolean updateJobClass(JobModel job) {
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE jobs SET job_title = ?, wage = ? WHERE job_id = ?");
            statement.setString(1, job.title);
            statement.setDouble(2, job.wage);
            statement.setInt(3, job.id);
            int rows = statement.executeUpdate();
            return rows > 0; // Return true if at least one row is affected by the update
        } catch (SQLException ex) {
            System.out.println("Failed to update job in the database. System exits with error!" + ex.getMessage());
            return false;
        }

    }

    @Override
    public JobModel deleteJobClass(int id) {
        try {
            JobModel deleted = readJobClass(id);
            if (deleted == null) {
                System.out.println("the job with id: " + id + "was not found");
                return null;
            }
            PreparedStatement statement = connection.prepareStatement("DELETE FROM jobs WHERE job_id = ?");
            statement.setInt(1, id);
            statement.executeUpdate();

            return deleted;
        }
        catch (Exception e) {
            System.out.println("something went wrong in the delete job class section: " + e.getMessage());
            return null;

        }

    }

    @Override
    public boolean createEmployee(Employee employee) {
        try{
            PreparedStatement statement = connection.prepareStatement("INSERT INTO employees (employee_id, employee_name, job_class) VALUES (?,?,?)");
            statement.setInt(1, employee.id);
            statement.setString(2, employee.employeeName);
            statement.setInt(3, employee.jobClass);

            int rows = statement.executeUpdate();
            return rows>0;
        }
        catch (Exception e) {
            System.out.println("there was an error in creating employee: " + e.getMessage());
            return false;
        }
    }

   @Override
    public Employee readEmployee(int id) {
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM employees WHERE employee_id = ?");
            statement.setInt(1,id);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                int employeeID = resultSet.getInt("employee_id");
                String name = resultSet.getString("employee_name");
                int jobClass = resultSet.getInt("job_class");
                return new Employee(employeeID, name, jobClass);
            }
            else {
                System.out.println("the employee with id: " + id + "was not found");
                return null;
            }

        }
        catch (Exception e) {
            System.out.println("there was an error in reading employees: " + e.getMessage());
            return null;
        }
    }


@Override
    public boolean updateEmployee(Employee employee){
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE employees SET employee_name = ?, job_class = ? WHERE employee_id = ?");
            statement.setString(1, employee.employeeName);
            statement.setInt(2, employee.jobClass);
            statement.setInt(3, employee.id);

            int rows = statement.executeUpdate();
            return rows > 0;
        }
        catch (Exception e) {
            System.out.println("there was an error in updating employees: " + e.getMessage());
            return false;
        }
    }


@Override
    public Employee deleteEmployee(int id){
        try {
            Employee deleted = readEmployee(id);
            if (deleted == null) {
                System.out.println("the employee  with id: " + id + "cannot be found");
                return null;
            }
            else {
                PreparedStatement statement = connection.prepareStatement("DELETE FROM employees WHERE employee_id = ?");
                statement.setInt(1, id);
                statement.executeUpdate();

                return deleted;
            }
        }
        catch(Exception e) {
            System.out.println("there was an error in deleting an employee");
            return null;
        }
    }

}
