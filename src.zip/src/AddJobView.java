import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddJobView extends JFrame {
    private JTextField jobIDField;
    private JTextField jobTitleField;
    private JTextField jobWageField;
    private JButton addButton;
    private JButton updateButton;
    private JButton readButton;
    private JButton deleteButton;

    private void displayJobDetails(JobModel job){
        JFrame details = new JFrame("Job Details");

        details.setSize(300,200);
        details.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        details.setLayout(new GridLayout(3,1));

        JLabel idLabel = new JLabel("ID: " + job.id);
        JLabel titleLabel = new JLabel("Job Title: " + job.title);
        JLabel wageLabel = new JLabel("Job Wage: " + job.wage);

        details.add(idLabel);
        details.add(titleLabel);
        details.add(wageLabel);

        details.setVisible(true);
    }

    public AddJobView() {

        setTitle("Add Job Class");
        this.setSize(500, 300);

        this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));

        this.getContentPane().add(new JLabel ("Job View! :)"));

//        JPanel main = new JPanel(new SpringLayout());
        JPanel main = new JPanel(new GridLayout(4,2,5,5));

        main.add(new JLabel("JobID:"));
        jobIDField = new JTextField();
        main.add(jobIDField);

        main.add(new JLabel("Title:"));
        jobTitleField = new JTextField();
        main.add(jobTitleField);

        main.add(new JLabel("Hourly wage:"));
        jobWageField = new JTextField();
        main.add(jobWageField);

        addButton = new JButton("Add Job Class");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id;
                try {
                    id = Integer.parseInt(jobIDField.getText());
                }
                catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid Job ID! Please provide a valid ID!");
                    return;
                }

                double wage;
                try {
                    wage = Double.parseDouble(jobWageField.getText());

                    if (wage < 0) {
                        JOptionPane.showMessageDialog(null, "Invalid hourly wage! It should be positive!");
                        return;
                    }
                }
                catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid number format! Please provide a valid number!");
                    return;
                }

                String entered_title = jobTitleField.getText().trim();

                if (entered_title.length() == 0) {
                    JOptionPane.showMessageDialog(null, "Invalid job title! Please provide a non-empty value!");
                    return;
                }

                // Done all validations! Make an object for this product!

                JobModel model = new JobModel();
                model.id = id;
                model.wage = wage;
                model.title = entered_title;

                // Store the model to the database

                boolean res = Application.getInstance().dataAdapter.createJobClass(model);
                if (!res) {
                    JOptionPane.showMessageDialog(null, "Job is NOT saved!");
                }
                else {
                    JOptionPane.showMessageDialog(null, "Job created!");
                }

            }
        });

        updateButton = new JButton("Update Job Class");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id;
                try {
                    id = Integer.parseInt(jobIDField.getText());
                }
                catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid Job ID! Please provide a valid ID!");
                    return;
                }
                double wage;
                try {
                    wage = Double.parseDouble(jobWageField.getText());
                    if (wage < 0) {
                        JOptionPane.showMessageDialog(null, "Invalid hourly wage! It should be positive!");
                        return;
                    }
                }
                catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid number format! Please provide a valid number!");
                    return;
                }

                String entered_title = jobTitleField.getText().trim();

                if (entered_title.length() == 0) {
                    JOptionPane.showMessageDialog(null, "Invalid job title! Please provide a non-empty value!");
                    return;
                }
                // Done all validations! Make an object for this product!

                JobModel model = new JobModel();
                model.id = id;
                model.wage = wage;
                model.title = entered_title;

                // Store the model to the database

                boolean res = Application.getInstance().dataAdapter.updateJobClass(model);
                if (!res) {
                    JOptionPane.showMessageDialog(null, "Job is NOT updated!");
                }
                else {
                    JOptionPane.showMessageDialog(null, "Job is Updated");
                }

            }
        });

        readButton = new JButton("Read Job Class");
        readButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id;
                try {
                    id = Integer.parseInt(jobIDField.getText());
                }
                catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid Job ID! Please provide a valid ID!");
                    return;
                }

                JobModel result = Application.getInstance().dataAdapter.readJobClass(id);
                if (result == null) {
                    JOptionPane.showMessageDialog(null, "Job with id: " + id + " was not found");
                }
                else {
                    displayJobDetails(result);
                }

            }
        });

        deleteButton = new JButton("Delete Job Class");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id;
                try {
                    id = Integer.parseInt(jobIDField.getText());
                }
                catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid Job ID! Please provide a valid ID!");
                    return;
                }

                JobModel result = Application.getInstance().dataAdapter.deleteJobClass(id);
                if (result == null) {
                    JOptionPane.showMessageDialog(null, "Job with id: " + id + " was not found");
                }
                else {
                    JOptionPane.showMessageDialog(null, "Job Class Deleted");
                }

            }
        });


        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
//        SpringUtilities.makeCompactGrid(main,
//                3, 2, //rows, cols
//                6, 6,        //initX, initY
//                6, 6);       //xPad, yPad
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(readButton);
        buttonPanel.add(deleteButton);


        add(main, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

//        this.getContentPane().add(main);
//        this.getContentPane().add(addButton);
//        this.getContentPane().add(updateButton);

    }


}
