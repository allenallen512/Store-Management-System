public class JobModel {
    public int id;
    public String title;
    public double wage;

    public JobModel() {
        this.id = 999;
        this.title = "untitled job";
        this.wage = 0.0;
    }

    public JobModel(int id, String title, double wage) {
        this.id = id;
        this.title = title;
        this.wage = wage;
    }
}
